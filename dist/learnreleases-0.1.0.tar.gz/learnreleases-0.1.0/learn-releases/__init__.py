def saludar(nombre):
    return f"¡Hola, {nombre}! Bienvenido al paquete learnReleases."